package com.example.adhanquran

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Change "ahmad55-dotcom/adhan-config" to your GitHub user / config repository if different. */
const val CONFIG_URL = "https://raw.githubusercontent.com/ahmad55-dotcom/adhan-config/main/config.json"

val DEFAULT_PHRASES = listOf(
    "سبحان الله", "الحمد لله", "الله أكبر", "لا إله إلا الله",
    "لا حول ولا قوة إلا بالله", "أستغفر الله", "اللهم صل وسلم على نبينا محمد"
)

/** Arabic text when the phone language is Arabic, otherwise English. */
fun t(ar: String, en: String): String = if (Locale.getDefault().language == "ar") ar else en

fun prayerLabel(c: Context, n: String): String {
    val id = c.resources.getIdentifier(n.lowercase(), "string", c.packageName)
    return if (id != 0) c.getString(id) else n
}

fun versionCode(c: Context): Long = try {
    PackageInfoCompat.getLongVersionCode(c.packageManager.getPackageInfo(c.packageName, 0))
} catch (e: Exception) { 0L }

fun versionName(c: Context): String = try {
    c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""
} catch (e: Exception) { "" }

/** Simple typed access to SharedPreferences "settings". */
object S {
    private fun p(c: Context) = c.getSharedPreferences("settings", 0)
    fun bool(c: Context, k: String, d: Boolean): Boolean = p(c).getBoolean(k, d)
    fun int(c: Context, k: String, d: Int): Int = p(c).getInt(k, d)
    fun str(c: Context, k: String, d: String): String = p(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: Any) {
        val e = p(c).edit()
        when (v) {
            is Boolean -> e.putBoolean(k, v)
            is Int -> e.putInt(k, v)
            is String -> e.putString(k, v)
            else -> {}
        }
        e.apply()
    }
}

object AppEvents { var dirty = true }

/** Remote configuration (config.json hosted on GitHub, edited from the control panel). */
object Cfg {
    var json by mutableStateOf(JSONObject())
        private set
    var gold by mutableStateOf(Color(0xFFD4AF37))
        private set
    var bg by mutableStateOf(Color(0xFF0A1F18))
        private set
    var card by mutableStateOf(Color(0xFF123528))
        private set
    var status by mutableStateOf("")
        private set

    fun load(c: Context) {
        val t = c.getSharedPreferences("cfg", 0).getString("json", null) ?: return
        try { applyJson(t) } catch (_: Exception) {}
    }

    suspend fun refresh(c: Context) {
        try {
            val t = withContext(Dispatchers.IO) {
                val con = URL("$CONFIG_URL?t=${System.currentTimeMillis()}").openConnection() as HttpURLConnection
                con.connectTimeout = 10000; con.readTimeout = 15000; con.useCaches = false
                con.inputStream.bufferedReader().use { it.readText() }
            }
            applyJson(t)
            c.getSharedPreferences("cfg", 0).edit().putString("json", t).apply()
            status = "OK"
        } catch (e: Exception) { status = e.message ?: e.toString() }
    }

    private fun applyJson(text: String) {
        val j = JSONObject(text)
        val th = j.optJSONObject("theme")
        fun col(k: String, d: Color): Color = try {
            Color(android.graphics.Color.parseColor(th?.optString(k, "") ?: ""))
        } catch (e: Exception) { d }
        json = j
        gold = col("accent", Color(0xFFD4AF37))
        bg = col("background", Color(0xFF0A1F18))
        card = col("card", Color(0xFF123528))
    }

    fun feature(n: String): Boolean = json.optJSONObject("features")?.optBoolean(n, true) ?: true
    fun appName(c: Context): String =
        json.optJSONObject("app")?.optString("name", "")?.takeIf { it.isNotBlank() } ?: c.getString(R.string.app_name)
    fun defInt(k: String, d: Int): Int = json.optJSONObject("defaults")?.optInt(k, d) ?: d
    fun muezzinUrl(): String = json.optString("muezzin_image_url", "")

    fun phrases(): List<String> {
        val a = json.optJSONArray("dhikr_phrases") ?: return DEFAULT_PHRASES
        val l = (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
        return l.ifEmpty { DEFAULT_PHRASES }
    }

    fun latestCode(): Int = json.optJSONObject("version")?.optInt("latest_code", 0) ?: 0
    fun latestName(): String = json.optJSONObject("version")?.optString("latest_name", "") ?: ""
    fun apkUrl(): String = json.optJSONObject("version")?.optString("apk_url", "") ?: ""
    fun updateMsg(): String = json.optJSONObject("version")?.optString("message", "") ?: ""

    fun popupEnabled(): Boolean = json.optJSONObject("popup")?.optBoolean("enabled", false) ?: false
    fun popupId(): String = json.optJSONObject("popup")?.optString("id", "") ?: ""
    fun popupTitle(): String = json.optJSONObject("popup")?.optString("title", "") ?: ""
    fun popupMessage(): String = json.optJSONObject("popup")?.optString("message", "") ?: ""

    fun hideBuiltinAdhkar(): Boolean = json.optBoolean("hide_builtin_adhkar", false)
    fun remoteAdhkar(): List<Dhikr> {
        val a = json.optJSONArray("adhkar") ?: return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val text = o.optString("text", "")
            if (text.isBlank()) null
            else Dhikr(o.optString("cat", "general"), o.optString("title_ar", ""), o.optString("title_en", ""), text, o.optInt("count", 1).coerceAtLeast(1))
        }
    }
}
