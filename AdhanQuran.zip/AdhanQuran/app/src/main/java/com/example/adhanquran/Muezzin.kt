package com.example.adhanquran

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Priority: picture chosen from the phone > image URL from the control panel > drawn mosque. */
@Composable
fun MuezzinImage(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val path = S.str(ctx, "muezzin_img", "")
    val url = Cfg.muezzinUrl()
    val bmp by produceState<ImageBitmap?>(null, path, url) { value = loadMuezzin(ctx, path, url) }
    val b = bmp
    if (b != null) Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Crop,
        modifier = modifier.clip(CircleShape).border(2.dp, Gold, CircleShape))
    else MosqueIllustration(modifier)
}

private suspend fun loadMuezzin(c: Context, path: String, url: String): ImageBitmap? = withContext(Dispatchers.IO) {
    try {
        if (path.isNotEmpty() && File(path).exists()) return@withContext decodeFile(path)
        if (url.isNotBlank()) {
            val f = File(c.filesDir, "muezzin_remote_${url.hashCode()}")
            try {
                val con = URL(url).openConnection() as HttpURLConnection
                con.connectTimeout = 10000; con.readTimeout = 20000
                con.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            } catch (e: Exception) { }
            if (f.exists()) return@withContext decodeFile(f.absolutePath)
        }
        null
    } catch (e: Exception) { null }
}

private fun decodeFile(p: String): ImageBitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(p, o)
    var s = 1
    while (o.outWidth / s > 1024 || o.outHeight / s > 1024) s *= 2
    val b = BitmapFactory.decodeFile(p, BitmapFactory.Options().apply { inSampleSize = s })
    return b?.asImageBitmap()
}

@Composable
fun MosqueIllustration(modifier: Modifier = Modifier) {
    val gold = Gold
    Canvas(modifier) {
        val w = size.width; val h = size.height
        drawCircle(gold.copy(alpha = .12f))
        drawCircle(gold, style = Stroke(3f))
        drawRect(gold, Offset(w * .30f, h * .55f), Size(w * .40f, h * .22f))
        drawArc(gold, 180f, 180f, true, Offset(w * .30f, h * .38f), Size(w * .40f, h * .34f))
        drawRect(gold, Offset(w * .20f, h * .34f), Size(w * .06f, h * .43f))
        drawRect(gold, Offset(w * .74f, h * .34f), Size(w * .06f, h * .43f))
        drawCircle(gold, w * .045f, Offset(w * .23f, h * .32f))
        drawCircle(gold, w * .045f, Offset(w * .77f, h * .32f))
        drawArc(gold, -50f, 280f, false, Offset(w * .44f, h * .20f), Size(w * .12f, h * .12f), style = Stroke(w * .03f))
    }
}
