package com.example.adhanquran

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Dhikr(val cat: String, val titleAr: String, val titleEn: String, val text: String, val count: Int)

private const val TAHLEEL = "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ"

val BUILTIN_ADHKAR = listOf(
    Dhikr("morning", "آية الكرسي", "Ayat al-Kursi",
        "اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ", 1),
    Dhikr("morning", "سورة الإخلاص", "Surah Al-Ikhlas",
        "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", 3),
    Dhikr("morning", "سورة الفلق", "Surah Al-Falaq",
        "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِن شَرِّ مَا خَلَقَ ۝ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", 3),
    Dhikr("morning", "سورة الناس", "Surah An-Nas",
        "قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ", 3),
    Dhikr("morning", "دعاء الصباح", "Morning supplication",
        "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، $TAHLEEL", 1),
    Dhikr("morning", "اللهم بك أصبحنا", "O Allah, by You we start the morning",
        "اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ", 1),
    Dhikr("morning", "الحماية من الضرر", "Protection",
        "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", 3),
    Dhikr("morning", "التسبيح", "Tasbih", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", 100),

    Dhikr("evening", "آية الكرسي", "Ayat al-Kursi",
        "اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ", 1),
    Dhikr("evening", "سورة الإخلاص", "Surah Al-Ikhlas",
        "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", 3),
    Dhikr("evening", "دعاء المساء", "Evening supplication",
        "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، $TAHLEEL", 1),
    Dhikr("evening", "اللهم بك أمسينا", "O Allah, by You we start the evening",
        "اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ", 1),
    Dhikr("evening", "الحماية من الضرر", "Protection",
        "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", 3),
    Dhikr("evening", "التسبيح", "Tasbih", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", 100),

    Dhikr("after", "الاستغفار", "Istighfar", "أَسْتَغْفِرُ اللَّهَ", 3),
    Dhikr("after", "اللهم أنت السلام", "O Allah, You are Peace",
        "اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ", 1),
    Dhikr("after", "سبحان الله", "SubhanAllah", "سُبْحَانَ اللَّهِ", 33),
    Dhikr("after", "الحمد لله", "Alhamdulillah", "الْحَمْدُ لِلَّهِ", 33),
    Dhikr("after", "الله أكبر", "Allahu Akbar", "اللَّهُ أَكْبَرُ", 33),
    Dhikr("after", "تمام المائة", "Completing one hundred", TAHLEEL, 1),

    Dhikr("general", "سبحان الله", "SubhanAllah", "سُبْحَانَ اللَّهِ", 33),
    Dhikr("general", "الحمد لله", "Alhamdulillah", "الْحَمْدُ لِلَّهِ", 33),
    Dhikr("general", "الله أكبر", "Allahu Akbar", "اللَّهُ أَكْبَرُ", 34),
    Dhikr("general", "لا إله إلا الله", "La ilaha illa Allah", "لَا إِلَهَ إِلَّا اللَّهُ", 100),
    Dhikr("general", "الحوقلة", "La hawla wa la quwwata", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", 100),
    Dhikr("general", "التسبيح والتعظيم", "Glorification", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ سُبْحَانَ اللَّهِ الْعَظِيمِ", 100),
    Dhikr("general", "الصلاة على النبي", "Salawat", "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", 10)
)

private fun catLabel(c: String): String = when (c) {
    "morning" -> t("أذكار الصباح", "Morning")
    "evening" -> t("أذكار المساء", "Evening")
    "after" -> t("بعد الصلاة", "After prayer")
    "general" -> t("تسبيح", "Tasbih")
    else -> c
}

@Composable
fun AdhkarScreen() {
    val all = remember(Cfg.json) { (if (Cfg.hideBuiltinAdhkar()) emptyList() else BUILTIN_ADHKAR) + Cfg.remoteAdhkar() }
    val cats = all.map { it.cat }.distinct()
    var sel by rememberSaveable { mutableStateOf("morning") }
    val shown = if (sel in cats) sel else (cats.firstOrNull() ?: "")
    val counts = remember { mutableStateMapOf<String, Int>() }
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.fillMaxSize()) {
        LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cats) { c -> FilterChip(selected = shown == c, onClick = { sel = c }, label = { Text(catLabel(c)) }) }
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(all.filter { it.cat == shown }) { d ->
                val key = d.cat + d.text.hashCode()
                val left = counts[key] ?: d.count
                val title = t(d.titleAr, d.titleEn).ifBlank { d.titleAr.ifBlank { d.titleEn } }
                Column(Modifier.fillMaxWidth().background(CardBg, shape).border(1.dp, CardBorder, shape).padding(16.dp)) {
                    if (title.isNotBlank()) Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(d.text, Modifier.fillMaxWidth(), color = TextLight,
                        style = TextStyle(fontSize = 20.sp, lineHeight = 34.sp, textDirection = TextDirection.Rtl), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(t("التكرار: ", "Repeat: ") + d.count, color = Dim, fontSize = 13.sp)
                        Box(Modifier.background(if (left == 0) Gold else Gold.copy(alpha = .2f), RoundedCornerShape(12.dp))
                            .clickable { counts[key] = if (left == 0) d.count else left - 1 }
                            .padding(horizontal = 22.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
                            Text(if (left == 0) "✓" else "$left", color = if (left == 0) BgPrimary else TextLight, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    }
                }
            }
        }
    }
}
