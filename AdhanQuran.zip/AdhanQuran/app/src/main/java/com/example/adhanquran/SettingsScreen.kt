package com.example.adhanquran

import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.IntentCompat
import kotlinx.coroutines.launch
import java.io.File

val METHODS = listOf(
    Triple(0, "تلقائي (حسب موقعك)", "Automatic (by location)"),
    Triple(5, "الهيئة المصرية العامة للمساحة", "Egyptian General Authority"),
    Triple(4, "أم القرى (مكة)", "Umm Al-Qura (Makkah)"),
    Triple(3, "رابطة العالم الإسلامي", "Muslim World League"),
    Triple(2, "ISNA (أمريكا الشمالية)", "ISNA (North America)"),
    Triple(1, "جامعة العلوم الإسلامية - كراتشي", "Karachi"),
    Triple(8, "الخليج", "Gulf Region"),
    Triple(9, "الكويت", "Kuwait"),
    Triple(10, "قطر", "Qatar"),
    Triple(11, "سنغافورة", "Singapore"),
    Triple(12, "فرنسا (UOIF)", "France (UOIF)"),
    Triple(13, "تركيا (ديانت)", "Turkey (Diyanet)"),
    Triple(14, "روسيا", "Russia"),
    Triple(7, "طهران", "Tehran")
)

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.fillMaxWidth().background(CardBg, shape).border(1.dp, CardBorder, shape).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        content()
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun soundName(c: Context, key: String): String {
    val v = S.str(c, key, "")
    if (v.isEmpty()) return t("الافتراضي", "Default")
    if (v == "silent") return t("صامت", "Silent")
    return try { RingtoneManager.getRingtone(c, Uri.parse(v))?.getTitle(c) ?: v } catch (e: Exception) { v }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE") val observe = tick

    fun set(k: String, v: Any, dirty: Boolean = false) {
        S.put(ctx, k, v)
        if (dirty) AppEvents.dirty = true
        tick++
    }

    var pickKey by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val u = r.data?.let { IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java) }
            set(pickKey, u?.toString() ?: "silent")
        }
    }
    fun pick(key: String) {
        pickKey = key
        val cur = S.str(ctx, key, "")
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
        if (cur.isNotEmpty() && cur != "silent") i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(cur))
        picker.launch(i)
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val f = File(ctx.filesDir, "muezzin_user_${System.currentTimeMillis()}.img")
                ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                set("muezzin_img", f.absolutePath)
            } catch (_: Exception) {}
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

        Section(t("الموقع", "Location")) {
            val manual = S.bool(ctx, "loc_manual", false)
            SwitchRow(t("تحديد الموقع يدوياً", "Manual location"), manual) { set("loc_manual", it, true) }
            if (manual) {
                var city by remember { mutableStateOf(S.str(ctx, "man_city", "")) }
                var country by remember { mutableStateOf(S.str(ctx, "man_country", "")) }
                OutlinedTextField(value = city, onValueChange = { city = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(t("المدينة (بالإنجليزية مثل Cairo)", "City (English, e.g. Cairo)")) })
                OutlinedTextField(value = country, onValueChange = { country = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(t("الدولة (بالإنجليزية مثل Egypt)", "Country (English, e.g. Egypt)")) })
                Button(onClick = {
                    set("man_city", city.trim(), true); set("man_country", country.trim(), true)
                    Toast.makeText(ctx, t("تم الحفظ", "Saved"), Toast.LENGTH_SHORT).show()
                }) { Text(t("تطبيق", "Apply")) }
            } else {
                Text(t("الموقع الحالي: ", "Current: ") + LocationHelper.city(ctx).ifEmpty { "—" }, color = Dim)
                Text(t("يتحدد تلقائياً من الـ GPS أو الإنترنت.", "Detected automatically from GPS or internet."), color = Dim, fontSize = 12.sp)
            }
        }

        Section(t("أوقات الصلاة", "Prayer times")) {
            val curMethod = PrayerRepo.method(ctx)
            var open by remember { mutableStateOf(false) }
            Text(t("طريقة الحساب", "Calculation method"))
            Box {
                OutlinedButton(onClick = { open = true }) {
                    val m = METHODS.firstOrNull { it.first == curMethod } ?: METHODS[0]
                    Text(t(m.second, m.third))
                }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    METHODS.forEach { m ->
                        DropdownMenuItem(text = { Text(t(m.second, m.third)) }, onClick = { set("method", m.first, true); open = false })
                    }
                }
            }
            Text(t("مذهب العصر", "Asr calculation"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = PrayerRepo.school(ctx) == 0, onClick = { set("school", 0, true) }, label = { Text(t("قياسي", "Standard")) })
                FilterChip(selected = PrayerRepo.school(ctx) == 1, onClick = { set("school", 1, true) }, label = { Text(t("حنفي", "Hanafi")) })
            }
            Text(t("تعديل يدوي بالدقائق لكل صلاة", "Manual adjustment per prayer (minutes)"))
            PrayerRepo.names.forEach { n ->
                val v = S.int(ctx, "off_$n", 0)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(prayerLabel(ctx, n), Modifier.weight(1f))
                    OutlinedButton(onClick = { set("off_$n", (v - 1).coerceAtLeast(-60), true) }) { Text("−") }
                    Text((if (v > 0) "+$v" else "$v"), Modifier.widthIn(min = 56.dp), textAlign = TextAlign.Center)
                    OutlinedButton(onClick = { set("off_$n", (v + 1).coerceAtMost(60), true) }) { Text("+") }
                }
            }
            TextButton(onClick = { PrayerRepo.names.forEach { set("off_$it", 0, true) } }) { Text(t("إعادة التعديلات إلى صفر", "Reset adjustments")) }
        }

        Section(t("الأذان والتنبيهات", "Adhan & notifications")) {
            SwitchRow(t("تفعيل الأذان", "Enable adhan"), S.bool(ctx, "adhan_on", true)) { set("adhan_on", it); AdhanScheduler.scheduleNext(ctx) }
            PrayerRepo.names.filter { it != "Sunrise" }.forEach { n ->
                SwitchRow(prayerLabel(ctx, n), S.bool(ctx, "pon_$n", true)) { set("pon_$n", it); AdhanScheduler.scheduleNext(ctx) }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t("صوت الأذان", "Adhan sound"))
                    Text(soundName(ctx, "adhan_sound"), color = Dim, fontSize = 12.sp)
                }
                OutlinedButton(onClick = { pick("adhan_sound") }) { Text(t("تغيير", "Change")) }
            }
            OutlinedButton(onClick = { Notif.post(ctx, "Fajr") }) { Text(t("تجربة التنبيه الآن", "Test notification now")) }
            if (Build.VERSION.SDK_INT >= 31 && !ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
                Text(t("⚠️ فعّل إذن المنبهات الدقيقة ليعمل الأذان في وقته", "⚠️ Allow exact alarms so the adhan fires on time"), color = MaterialTheme.colorScheme.error)
                Button(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:${ctx.packageName}")))
                }) { Text(t("فتح الإعداد", "Open setting")) }
            }
            OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) {
                Text(t("استثناء التطبيق من توفير البطارية", "Battery optimization settings"))
            }
        }

        Section(t("تذكير الذكر المنبثق", "Dhikr pop-up reminder")) {
            SwitchRow(t("تفعيل التذكير", "Enable reminder"), S.bool(ctx, "dhikr_on", false)) { set("dhikr_on", it); DhikrScheduler.schedule(ctx) }
            Text(t("كل كم دقيقة", "Every"))
            val cur = S.int(ctx, "dhikr_interval", Cfg.defInt("dhikr_interval_min", 30))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(15, 30, 60, 120, 240).forEach { m ->
                    FilterChip(selected = cur == m, onClick = { set("dhikr_interval", m); DhikrScheduler.schedule(ctx) },
                        label = { Text(if (m < 60) "$m" + t(" د", " m") else "${m / 60}" + t(" س", " h")) })
                }
            }
            Text(t("اختر الأذكار (إن لم تختر شيئاً تُستخدم كلها)", "Choose phrases (none selected = all)"))
            val sel = S.str(ctx, "dhikr_phrases", "").split("|").filter { it.isNotBlank() }
            Cfg.phrases().forEach { ph ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = ph in sel, onCheckedChange = { on ->
                        val n = if (on) sel + ph else sel - ph
                        set("dhikr_phrases", n.joinToString("|"))
                    })
                    Text(ph)
                }
            }
            var custom by remember { mutableStateOf(S.str(ctx, "dhikr_custom", "")) }
            OutlinedTextField(value = custom, onValueChange = { custom = it; S.put(ctx, "dhikr_custom", it) }, modifier = Modifier.fillMaxWidth(),
                label = { Text(t("ذكر من عندك (اختياري)", "Your own phrase (optional)")) })
            SwitchRow(t("نطق الذكر بصوت عالٍ", "Speak the phrase aloud"), S.bool(ctx, "dhikr_tts", false)) { set("dhikr_tts", it) }
            Text(t("يحتاج صوتاً عربياً مثبّتاً في إعدادات النطق بجهازك.", "Needs an Arabic voice installed in your phone's text-to-speech settings."), color = Dim, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t("صوت التذكير", "Reminder sound"))
                    Text(soundName(ctx, "dhikr_sound"), color = Dim, fontSize = 12.sp)
                }
                OutlinedButton(onClick = { pick("dhikr_sound") }) { Text(t("تغيير", "Change")) }
            }
            OutlinedButton(onClick = { Notif.postDhikr(ctx, Cfg.phrases().firstOrNull() ?: "سبحان الله") }) { Text(t("تجربة التذكير الآن", "Test reminder now")) }
        }

        Section(t("صورة المؤذن", "Muezzin picture")) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                MuezzinImage(Modifier.size(72.dp))
                OutlinedButton(onClick = { imagePicker.launch("image/*") }) { Text(t("اختيار صورة", "Choose image")) }
                TextButton(onClick = { set("muezzin_img", "") }) { Text(t("افتراضي", "Default")) }
            }
        }

        Section(t("حول التطبيق", "About")) {
            Text(t("الإصدار الحالي: ", "Version: ") + versionName(ctx) + " (" + versionCode(ctx) + ")")
            if (Cfg.latestCode() > 0) Text(t("أحدث إصدار: ", "Latest: ") + Cfg.latestName() + " (" + Cfg.latestCode() + ")", color = Dim)
            Text(t("حالة الإعدادات عن بُعد: ", "Remote config: ") + Cfg.status.ifEmpty { "—" }, color = Dim, fontSize = 12.sp)
            OutlinedButton(onClick = { scope.launch { Cfg.refresh(ctx); Toast.makeText(ctx, Cfg.status, Toast.LENGTH_SHORT).show() } }) {
                Text(t("تحديث الإعدادات الآن", "Refresh config now"))
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
