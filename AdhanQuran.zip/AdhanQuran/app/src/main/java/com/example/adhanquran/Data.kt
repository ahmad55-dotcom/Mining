package com.example.adhanquran

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.location.LocationManagerCompat
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

class App : Application() {
    companion object { lateinit var ctx: Context }
    override fun onCreate() { super.onCreate(); ctx = this; Cfg.load(this) }
}

/** HTTP GET with on-disk cache so Quran text works offline after first load. */
object Api {
    suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val f = File(App.ctx.filesDir, "c_" + url.hashCode())
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 30000
            val t = c.inputStream.bufferedReader().use { it.readText() }
            f.writeText(t); t
        } catch (e: Exception) {
            if (f.exists()) f.readText() else throw e
        }
    }
}

object LocationHelper {
    private fun permitted(c: Context) =
        c.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
        c.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private suspend fun gps(c: Context): Location? {
        if (!permitted(c)) return null
        return try {
            val lm = c.getSystemService(LocationManager::class.java)
            val ps = lm.getProviders(true)
            val last = ps.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
            last ?: ps.firstOrNull()?.let { p ->
                withTimeoutOrNull(8000L) {
                    suspendCancellableCoroutine<Location?> { cont ->
                        val cs: androidx.core.os.CancellationSignal? = null
                        val cb = androidx.core.util.Consumer<Location?> { l -> if (cont.isActive) cont.resume(l) }
                        LocationManagerCompat.getCurrentLocation(lm, p, cs, c.mainExecutor, cb)
                    }
                }
            }
        } catch (e: Exception) { null }
    }

    /** Manual -> saved coordinates. Auto -> GPS, then approximate location from the internet, then last saved. */
    suspend fun best(c: Context): Pair<Double, Double>? {
        if (S.bool(c, "loc_manual", false)) return saved(c)
        val sp = c.getSharedPreferences("loc", 0)
        fun save(lat: Double, lon: Double) = sp.edit().putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).apply()
        gps(c)?.let {
            save(it.latitude, it.longitude)
            geocode(c, it.latitude, it.longitude)?.let { n -> sp.edit().putString("city", n).apply() }
            return it.latitude to it.longitude
        }
        try {
            val o = JSONObject(Api.get("https://ipwho.is/"))
            if (o.optBoolean("success", true) && o.has("latitude")) {
                val lat = o.getDouble("latitude"); val lon = o.getDouble("longitude")
                val n = listOf(o.optString("city"), o.optString("country")).filter { it.isNotBlank() }.joinToString(", ")
                if (n.isNotEmpty()) sp.edit().putString("city", n).apply()
                save(lat, lon); return lat to lon
            }
        } catch (_: Exception) {}
        return saved(c)
    }

    @Suppress("DEPRECATION")
    private suspend fun geocode(c: Context, lat: Double, lon: Double): String? = withContext(Dispatchers.IO) {
        try {
            if (!android.location.Geocoder.isPresent()) return@withContext null
            val a = android.location.Geocoder(c, Locale.getDefault()).getFromLocation(lat, lon, 1)?.firstOrNull()
            a?.let { listOf(it.locality ?: it.subAdminArea ?: it.adminArea, it.countryName).filterNotNull().filter { x -> x.isNotBlank() }.joinToString(", ") }
        } catch (e: Exception) { null }
    }

    fun city(c: Context): String = c.getSharedPreferences("loc", 0).getString("city", "") ?: ""

    fun saved(c: Context): Pair<Double, Double>? {
        val sp = c.getSharedPreferences("loc", 0)
        return if (sp.contains("lat")) sp.getFloat("lat", 0f).toDouble() to sp.getFloat("lon", 0f).toDouble() else null
    }
}

data class Day(val date: LocalDate, val times: Map<String, LocalTime>, val hijri: String)

object PrayerRepo {
    val names = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private fun prefs(c: Context) = c.getSharedPreferences("prayer", 0)
    fun method(c: Context) = S.int(c, "method", Cfg.defInt("calc_method", 0))
    fun school(c: Context) = S.int(c, "school", Cfg.defInt("school", 0))
    private fun key(c: Context, d: LocalDate) =
        "cal_${method(c)}_${school(c)}_${if (S.bool(c, "loc_manual", false)) "m" else "a"}_${d.year}-${d.monthValue}"
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Downloads this month + next month. Returns null on success, or an error message. */
    suspend fun refreshAll(c: Context): String? {
        try {
            val manual = S.bool(c, "loc_manual", false)
            val extra = (if (method(c) > 0) "&method=${method(c)}" else "") + "&school=${school(c)}"
            val base: String
            var label = ""
            if (manual) {
                val city = S.str(c, "man_city", ""); val country = S.str(c, "man_country", "")
                if (city.isBlank()) return t("اكتب اسم المدينة من الإعدادات", "Enter a city in Settings")
                label = listOf(city, country).filter { it.isNotBlank() }.joinToString(", ")
                base = "https://api.aladhan.com/v1/calendarByCity?city=${enc(city)}&country=${enc(country)}"
            } else {
                val pos = LocationHelper.best(c) ?: return "No location (GPS / internet)"
                base = "https://api.aladhan.com/v1/calendar?latitude=${pos.first}&longitude=${pos.second}"
            }
            val now = LocalDate.now()
            for (m in listOf(now, now.plusMonths(1))) {
                val json = Api.get("$base&month=${m.monthValue}&year=${m.year}$extra")
                prefs(c).edit().putString(key(c, m), json).apply()
                if (manual && m == now) {
                    val meta = JSONObject(json).getJSONArray("data").getJSONObject(0).optJSONObject("meta")
                    val e = c.getSharedPreferences("loc", 0).edit().putString("city", label)
                    if (meta != null) e.putFloat("lat", meta.getDouble("latitude").toFloat()).putFloat("lon", meta.getDouble("longitude").toFloat())
                    e.apply()
                }
            }
            return null
        } catch (e: Exception) {
            return t("تعذّر التحميل، تأكد من الإنترنت واسم المدينة: ", "Could not load, check internet / city name: ") + (e.message ?: "")
        }
    }

    fun day(c: Context, date: LocalDate): Day? {
        val json = prefs(c).getString(key(c, date), null) ?: return null
        return runCatching {
            val o = JSONObject(json).getJSONArray("data").getJSONObject(date.dayOfMonth - 1)
            val tm = o.getJSONObject("timings")
            val h = o.getJSONObject("date").getJSONObject("hijri")
            Day(date, names.associateWith {
                LocalTime.parse(tm.getString(it).substring(0, 5)).plusMinutes(S.int(c, "off_$it", 0).toLong())
            }, "${h.getString("day")} ${h.getJSONObject("month").getString(if (Locale.getDefault().language == "ar") "ar" else "en")} ${h.getString("year")}")
        }.getOrNull()
    }

    fun next(c: Context, now: LocalDateTime, includeSunrise: Boolean): Pair<String, LocalDateTime>? {
        for (offset in 0..1) {
            val d = day(c, now.toLocalDate().plusDays(offset.toLong())) ?: continue
            for (n in names) {
                if (n == "Sunrise" && !includeSunrise) continue
                if (!includeSunrise && !S.bool(c, "pon_$n", true)) continue
                val dt = LocalDateTime.of(d.date, d.times[n]!!)
                if (dt.isAfter(now)) return n to dt
            }
        }
        return null
    }
}

object AdhanScheduler {
    fun scheduleNext(c: Context) {
        val n = PrayerRepo.next(c, LocalDateTime.now(), false) ?: return
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            c, 1, Intent(c, AdhanReceiver::class.java).putExtra("name", n.first),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val t = n.second.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
    }
}

object DhikrScheduler {
    private fun pending(c: Context) = PendingIntent.getBroadcast(
        c, 2, Intent(c, DhikrReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pending(c)
        if (!S.bool(c, "dhikr_on", false)) { am.cancel(pi); return }
        val mins = S.int(c, "dhikr_interval", Cfg.defInt("dhikr_interval_min", 30)).coerceAtLeast(5)
        val at = System.currentTimeMillis() + mins * 60_000L
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }
}

object Notif {
    /** key: settings key holding the chosen sound ("" = default, "silent" = none). */
    fun soundUri(c: Context, key: String, rawName: String?): Uri? {
        val v = S.str(c, key, "")
        if (v == "silent") return null
        if (v.isNotEmpty()) return Uri.parse(v)
        if (rawName != null) {
            val raw = c.resources.getIdentifier(rawName, "raw", c.packageName)
            if (raw != 0) return Uri.parse("android.resource://${c.packageName}/$raw")
        }
        return android.provider.Settings.System.DEFAULT_NOTIFICATION_URI
    }

    /** Channel sound cannot change after creation, so each sound gets its own channel id. */
    fun channel(c: Context, prefix: String, name: String, sound: Uri?): String {
        val id = prefix + "_" + (sound?.toString()?.hashCode() ?: 0)
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(sound, AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            nm.createNotificationChannel(ch)
        }
        return id
    }

    fun post(c: Context, name: String) {
        val ch = channel(c, "adhan", "Adhan", soundUri(c, "adhan_sound", "adhan"))
        val title = prayerLabel(c, name)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(NotificationManager::class.java).notify(name.hashCode(), NotificationCompat.Builder(c, ch)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title)
            .setContentText(Cfg.appName(c)).setAutoCancel(true)
            .setContentIntent(open).setPriority(NotificationCompat.PRIORITY_HIGH).build())
    }

    fun postDhikr(c: Context, text: String) {
        val ch = channel(c, "dhikr", "Dhikr", soundUri(c, "dhikr_sound", null))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(NotificationManager::class.java).notify(777, NotificationCompat.Builder(c, ch)
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(text)
            .setContentText(Cfg.appName(c)).setAutoCancel(true)
            .setContentIntent(open).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_VIBRATE).build())
    }
}

class AdhanReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val name = i.getStringExtra("name") ?: "Fajr"
        if (S.bool(c, "adhan_on", true)) Notif.post(c, name)
        AdhanScheduler.scheduleNext(c)
    }
}

class DhikrReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!S.bool(c, "dhikr_on", false)) return
        val chosen = S.str(c, "dhikr_phrases", "").split("|").filter { it.isNotBlank() }.toMutableList()
        val custom = S.str(c, "dhikr_custom", "").trim()
        if (custom.isNotEmpty()) chosen.add(custom)
        val pool = if (chosen.isEmpty()) Cfg.phrases() else chosen
        val text = pool.random()
        Notif.postDhikr(c, text)
        DhikrScheduler.schedule(c)
        if (S.bool(c, "dhikr_tts", false)) speak(c, text, goAsync())
    }

    private fun speak(c: Context, text: String, pr: BroadcastReceiver.PendingResult) {
        val done = AtomicBoolean(false)
        var tts: TextToSpeech? = null
        fun finish() { if (done.compareAndSet(false, true)) { tts?.shutdown(); pr.finish() } }
        tts = TextToSpeech(c.applicationContext) { st ->
            val t = tts
            if (st == TextToSpeech.SUCCESS && t != null) {
                t.setLanguage(Locale("ar"))
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { finish() }
                    override fun onError(id: String?) { finish() }
                })
                t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dhikr")
            } else finish()
        }
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 15000)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { AdhanScheduler.scheduleNext(c); DhikrScheduler.schedule(c) }
}

data class Surah(val n: Int, val ar: String, val en: String, val count: Int)

val RECITERS = listOf(
    "ar.alafasy" to "Mishary Alafasy", "ar.abdulbasitmurattal" to "Abdul Basit",
    "ar.husary" to "Al-Husary", "ar.minshawi" to "Al-Minshawi", "ar.mahermuaiqly" to "Maher Al Muaiqly"
)

object QuranRepo {
    private const val B = "https://api.alquran.cloud/v1"
    suspend fun surahs(): List<Surah> {
        val a = JSONObject(Api.get("$B/surah")).getJSONArray("data")
        return (0 until a.length()).map { val o = a.getJSONObject(it)
            Surah(o.getInt("number"), o.getString("name"), o.getString("englishName"), o.getInt("numberOfAyahs")) }
    }
    suspend fun ayahs(n: Int): List<String> {
        val a = JSONObject(Api.get("$B/surah/$n/quran-uthmani")).getJSONObject("data").getJSONArray("ayahs")
        return (0 until a.length()).map { a.getJSONObject(it).getString("text") }
    }
    suspend fun audio(n: Int, reciter: String): List<String> {
        val a = JSONObject(Api.get("$B/surah/$n/$reciter")).getJSONObject("data").getJSONArray("ayahs")
        return (0 until a.length()).map { a.getJSONObject(it).getString("audio") }
    }
}

object AudioPlayer { val exo: ExoPlayer by lazy { ExoPlayer.Builder(App.ctx).build() } }
