package com.example.adhanquran

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.location.LocationManagerCompat
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import kotlin.coroutines.resume

class App : Application() {
    companion object { lateinit var ctx: Context }
    override fun onCreate() { super.onCreate(); ctx = this }
}

/** HTTP GET with on-disk cache so Quran text works offline after first load. */
object Api {
    suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val f = File(App.ctx.filesDir, "c_" + url.hashCode())
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 30000
            val t = c.inputStream.bufferedReader().use { it.readText() }
            f.writeText(t); t
        } catch (e: Exception) {
            if (f.exists()) f.readText() else throw e
        }
    }
}

object LocationHelper {
    @SuppressLint("MissingPermission")
    suspend fun get(c: Context): Location? {
        val lm = c.getSystemService(LocationManager::class.java)
        val ps = lm.getProviders(true)
        val last = ps.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
        val loc = last ?: ps.firstOrNull()?.let { p ->
            suspendCancellableCoroutine<Location?> { cont ->
                LocationManagerCompat.getCurrentLocation(lm, p, null, c.mainExecutor) { cont.resume(it) }
            }
        }
        val sp = c.getSharedPreferences("loc", 0)
        if (loc != null) sp.edit().putFloat("lat", loc.latitude.toFloat()).putFloat("lon", loc.longitude.toFloat()).apply()
        return loc
    }
    fun saved(c: Context): Pair<Double, Double>? {
        val sp = c.getSharedPreferences("loc", 0)
        return if (sp.contains("lat")) sp.getFloat("lat", 0f).toDouble() to sp.getFloat("lon", 0f).toDouble() else null
    }
}

data class Day(val date: LocalDate, val times: Map<String, LocalTime>, val hijri: String)

object PrayerRepo {
    val names = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private fun prefs(c: Context) = c.getSharedPreferences("prayer", 0)
    private fun key(d: LocalDate) = "cal_${d.year}-${d.monthValue}"

    /** Aladhan picks the calculation method automatically from the coordinates. */
    suspend fun refresh(c: Context, lat: Double, lon: Double) {
        val now = LocalDate.now()
        for (m in listOf(now, now.plusMonths(1))) {
            val json = Api.get("https://api.aladhan.com/v1/calendar?latitude=$lat&longitude=$lon&month=${m.monthValue}&year=${m.year}")
            prefs(c).edit().putString(key(m), json).apply()
        }
    }

    fun day(c: Context, date: LocalDate): Day? {
        val json = prefs(c).getString(key(date), null) ?: return null
        return runCatching {
            val o = JSONObject(json).getJSONArray("data").getJSONObject(date.dayOfMonth - 1)
            val t = o.getJSONObject("timings")
            val h = o.getJSONObject("date").getJSONObject("hijri")
            Day(date, names.associateWith { LocalTime.parse(t.getString(it).substring(0, 5)) },
                "${h.getString("day")} ${h.getJSONObject("month").getString("en")} ${h.getString("year")}")
        }.getOrNull()
    }

    fun next(c: Context, now: LocalDateTime, includeSunrise: Boolean): Pair<String, LocalDateTime>? {
        for (offset in 0..1) {
            val d = day(c, now.toLocalDate().plusDays(offset.toLong())) ?: continue
            for (n in names) {
                if (n == "Sunrise" && !includeSunrise) continue
                val dt = LocalDateTime.of(d.date, d.times[n]!!)
                if (dt.isAfter(now)) return n to dt
            }
        }
        return null
    }
}

object AdhanScheduler {
    fun scheduleNext(c: Context) {
        val n = PrayerRepo.next(c, LocalDateTime.now(), false) ?: return
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            c, 1, Intent(c, AdhanReceiver::class.java).putExtra("name", n.first),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val t = n.second.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
    }
}

class AdhanReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val name = i.getStringExtra("name") ?: "Fajr"
        val nm = c.getSystemService(NotificationManager::class.java)
        // Optional: drop adhan.mp3 into res/raw to use it as the notification sound.
        val raw = c.resources.getIdentifier("adhan", "raw", c.packageName)
        val sound = if (raw != 0) Uri.parse("android.resource://${c.packageName}/$raw") else null
        val ch = NotificationChannel("adhan_v1", "Adhan", NotificationManager.IMPORTANCE_HIGH)
        if (sound != null) ch.setSound(sound, AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        nm.createNotificationChannel(ch)
        val sid = c.resources.getIdentifier(name.lowercase(), "string", c.packageName)
        val title = if (sid != 0) c.getString(sid) else name
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(name.hashCode(), NotificationCompat.Builder(c, "adhan_v1")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title)
            .setContentText(c.getString(R.string.app_name)).setAutoCancel(true)
            .setContentIntent(open).setPriority(NotificationCompat.PRIORITY_HIGH).build())
        AdhanScheduler.scheduleNext(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { AdhanScheduler.scheduleNext(c) }
}

data class Surah(val n: Int, val ar: String, val en: String, val count: Int)

val RECITERS = listOf(
    "ar.alafasy" to "Mishary Alafasy", "ar.abdulbasitmurattal" to "Abdul Basit",
    "ar.husary" to "Al-Husary", "ar.minshawi" to "Al-Minshawi", "ar.mahermuaiqly" to "Maher Al Muaiqly"
)

object QuranRepo {
    private const val B = "https://api.alquran.cloud/v1"
    suspend fun surahs(): List<Surah> {
        val a = JSONObject(Api.get("$B/surah")).getJSONArray("data")
        return (0 until a.length()).map { val o = a.getJSONObject(it)
            Surah(o.getInt("number"), o.getString("name"), o.getString("englishName"), o.getInt("numberOfAyahs")) }
    }
    suspend fun ayahs(n: Int): List<String> {
        val a = JSONObject(Api.get("$B/surah/$n/quran-uthmani")).getJSONObject("data").getJSONArray("ayahs")
        return (0 until a.length()).map { a.getJSONObject(it).getString("text") }
    }
    suspend fun audio(n: Int, reciter: String): List<String> {
        val a = JSONObject(Api.get("$B/surah/$n/$reciter")).getJSONObject("data").getJSONArray("ayahs")
        return (0 until a.length()).map { a.getJSONObject(it).getString("audio") }
    }
}

object AudioPlayer { val exo: ExoPlayer by lazy { ExoPlayer.Builder(App.ctx).build() } }
