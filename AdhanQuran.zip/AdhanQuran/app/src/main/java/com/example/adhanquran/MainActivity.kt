package com.example.adhanquran

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme())
        darkColorScheme(primary = Color(0xFF4CC9A0), secondary = Color(0xFFE6C65C), background = Color(0xFF0D1B17), surface = Color(0xFF14261F))
    else lightColorScheme(primary = Color(0xFF0B6B4F), secondary = Color(0xFFC9A227), background = Color(0xFFF6F8F5), surface = Color.White)
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items = listOf(Triple(R.string.tab_prayer, Icons.Filled.AccessTime, 0),
        Triple(R.string.tab_qibla, Icons.Filled.Explore, 1), Triple(R.string.tab_quran, Icons.Filled.MenuBook, 2))
    Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = {
        NavigationBar { items.forEach { (label, icon, i) ->
            NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, null) }, label = { Text(stringResource(label)) })
        } }
    }) { p -> Box(Modifier.padding(p).fillMaxSize()) { when (tab) { 0 -> PrayerScreen(); 1 -> QiblaScreen(); else -> QuranScreen() } } }
}

private fun hasLoc(c: Context) =
    ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
    ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

@Composable
fun PrayerScreen() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasLoc(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasLoc(ctx) }
    var day by remember { mutableStateOf<Day?>(null) }
    var error by remember { mutableStateOf(false) }
    var errMsg by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    LaunchedEffect(granted, reload) {
        error = false; errMsg = ""
        val pos = LocationHelper.best(ctx)
        if (pos == null) errMsg = "No location (GPS / internet)"
        else try { PrayerRepo.refresh(ctx, pos.first, pos.second) } catch (e: Exception) { errMsg = e.toString() }
        day = PrayerRepo.day(ctx, LocalDate.now())
        if (day == null) { error = true; if (errMsg.isEmpty()) errMsg = "Could not read prayer times" } else AdhanScheduler.scheduleNext(ctx)
    }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!granted) Card { Column(Modifier.padding(16.dp)) {
            Text(stringResource(R.string.need_location))
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
                launcher.launch(p.toTypedArray())
            }) { Text(stringResource(R.string.allow)) }
        } }
        val nxt = PrayerRepo.next(ctx, now, true)
        if (nxt != null) {
            val d = Duration.between(now, nxt.second)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(R.string.next_prayer), color = Color.White.copy(alpha = .8f))
                    Text(prayerLabel(ctx, nxt.first), fontSize = 32.sp, color = Color.White)
                    Text("%02d:%02d:%02d".format(d.toHours(), d.toMinutesPart(), d.toSecondsPart()), fontSize = 40.sp, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
        day?.let { dd ->
            Text("${LocalDate.now()} · ${dd.hijri}", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .7f))
            val f = DateTimeFormatter.ofPattern("HH:mm")
            PrayerRepo.names.forEach { n ->
                val isNext = nxt?.first == n
                Row(Modifier.fillMaxWidth().background(
                        if (isNext) MaterialTheme.colorScheme.primary.copy(alpha = .15f) else MaterialTheme.colorScheme.surface,
                        RoundedCornerShape(14.dp)).padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(prayerLabel(ctx, n), fontSize = 18.sp)
                    Text(dd.times[n]!!.format(f), fontSize = 18.sp)
                }
            }
        }
        if (error) { Text(errMsg, color = MaterialTheme.colorScheme.error); Button(onClick = { reload++ }) { Text(stringResource(R.string.retry)) } }
    }
}

private fun prayerLabel(c: Context, n: String): String {
    val id = c.resources.getIdentifier(n.lowercase(), "string", c.packageName)
    return if (id != 0) c.getString(id) else n
}

private fun qiblaBearing(lat: Double, lon: Double): Double {
    val p1 = Math.toRadians(lat); val p2 = Math.toRadians(21.4225); val dl = Math.toRadians(39.8262 - lon)
    val y = sin(dl) * cos(p2); val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
    return (Math.toDegrees(atan2(y, x)) + 360) % 360
}
private fun distanceKm(lat: Double, lon: Double): Double {
    val r = 6371.0; val p1 = Math.toRadians(lat); val p2 = Math.toRadians(21.4225)
    val dp = p2 - p1; val dl = Math.toRadians(39.8262 - lon)
    val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
    return 2 * r * asin(sqrt(a))
}

@Composable
fun QiblaScreen() {
    val ctx = LocalContext.current
    var pos by remember { mutableStateOf(LocationHelper.saved(ctx)) }
    var azimuth by remember { mutableFloatStateOf(0f) }
    var lowAcc by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { LocationHelper.best(ctx)?.let { pos = it } }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        var sn = 0.0; var cs = 1.0
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val r = FloatArray(9); SensorManager.getRotationMatrixFromVector(r, e.values)
                val o = FloatArray(3); SensorManager.getOrientation(r, o)
                val a = o[0].toDouble()
                sn += 0.1 * (sin(a) - sn); cs += 0.1 * (cos(a) - cs)   // low-pass filter on the angle
                azimuth = Math.toDegrees(atan2(sn, cs)).toFloat()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) { lowAcc = a < SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM }
        }
        if (s != null) sm.registerListener(l, s, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(l) }
    }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        val p = pos
        if (p == null) { Text(stringResource(R.string.need_location)); return@Column }
        val q = qiblaBearing(p.first, p.second).toFloat()
        val diff = ((q - azimuth + 540) % 360) - 180
        val aligned = abs(diff) < 3
        val color = if (aligned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
        Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().rotate(-azimuth)) { // dial turns with the phone, N marker at top
                drawCircle(color.copy(alpha = .2f)); drawCircle(color, style = androidx.compose.ui.graphics.drawscope.Stroke(4f))
                drawLine(Color.Red, Offset(size.width / 2, 8f), Offset(size.width / 2, 40f), strokeWidth = 6f)
            }
            Canvas(Modifier.fillMaxSize().rotate(q - azimuth)) {
                val cx = size.width / 2; val path = Path().apply {
                    moveTo(cx, 30f); lineTo(cx - 28f, size.height / 2); lineTo(cx + 28f, size.height / 2); close() }
                drawPath(path, color)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.qibla_info, q.roundToInt(), distanceKm(p.first, p.second).roundToInt()), fontSize = 18.sp)
        if (lowAcc) Text(stringResource(R.string.calibrate), color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
    }
}

@Composable
fun QuranScreen() {
    var list by remember { mutableStateOf<List<Surah>?>(null) }
    var err by remember { mutableStateOf(false) }
    var tries by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Surah?>(null) }
    LaunchedEffect(tries) { err = false; try { list = QuranRepo.surahs() } catch (_: Exception) { err = true } }
    BackHandler(open != null) { open = null }
    val s = open
    when {
        s != null -> Reader(s)
        list != null -> LazyColumn { items(list!!) { sr ->
            ListItem(headlineContent = { Text(sr.en) }, supportingContent = { Text("${sr.count}") },
                leadingContent = { Text("${sr.n}") }, trailingContent = { Text(sr.ar, fontSize = 20.sp) },
                modifier = Modifier.clickable { open = sr })
            HorizontalDivider()
        } }
        err -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Button(onClick = { tries++ }) { Text(stringResource(R.string.retry)) } }
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable
fun Reader(s: Surah) {
    var ayahs by remember { mutableStateOf<List<String>>(emptyList()) }
    var size by rememberSaveable { mutableFloatStateOf(26f) }
    var reciter by rememberSaveable { mutableStateOf(RECITERS[0].first) }
    var playing by remember { mutableStateOf(false) }
    var idx by remember { mutableIntStateOf(-1) }
    var err by remember { mutableStateOf(false) }
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(s) { try { ayahs = QuranRepo.ayahs(s.n) } catch (_: Exception) { err = true } }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) { playing = p }
            override fun onMediaItemTransition(m: MediaItem?, r: Int) { idx = AudioPlayer.exo.currentMediaItemIndex }
        }
        AudioPlayer.exo.addListener(l)
        onDispose { AudioPlayer.exo.removeListener(l); AudioPlayer.exo.stop() }
    }
    LaunchedEffect(idx) { if (idx in ayahs.indices) state.animateScrollToItem(idx) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text("${s.n}. ${s.en} — ${s.ar}", fontSize = 18.sp)
            Text("${stringResource(R.string.text_size)}: ${size.roundToInt()}")
            Slider(value = size, onValueChange = { size = it }, valueRange = 16f..52f)
            Text(stringResource(R.string.reciter))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(RECITERS) { (id, nm) ->
                FilterChip(selected = reciter == id, onClick = { reciter = id; AudioPlayer.exo.stop(); idx = -1 }, label = { Text(nm) }) } }
            Button(onClick = {
                if (playing) AudioPlayer.exo.stop() else scope.launch {
                    try {
                        val urls = QuranRepo.audio(s.n, reciter)
                        AudioPlayer.exo.setMediaItems(urls.map { MediaItem.fromUri(it) })
                        AudioPlayer.exo.prepare(); AudioPlayer.exo.play()
                    } catch (_: Exception) { err = true }
                }
            }) { Text(stringResource(if (playing) R.string.stop else R.string.play)) }
        }
        if (err) Text(stringResource(R.string.retry), Modifier.padding(16.dp))
        if (ayahs.isEmpty() && !err) Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        LazyColumn(state = state, contentPadding = PaddingValues(16.dp)) {
            itemsIndexed(ayahs) { i, t ->
                Text("$t ﴿${i + 1}﴾", Modifier.fillMaxWidth()
                    .background(if (i == idx) MaterialTheme.colorScheme.primary.copy(alpha = .18f) else Color.Transparent, RoundedCornerShape(10.dp))
                    .padding(vertical = 8.dp, horizontal = 6.dp),
                    style = TextStyle(fontSize = size.sp, lineHeight = (size * 1.8f).sp, textDirection = TextDirection.Rtl),
                    textAlign = TextAlign.Start)
            }
        }
    }
}
