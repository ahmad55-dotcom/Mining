package com.example.adhanquran

import android.Manifest
import android.net.Uri
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import android.content.Intent
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Root() } }
    }
}

val BgPrimary: Color get() = Cfg.bg
val BgSecondary: Color get() = Cfg.card
val Gold: Color get() = Cfg.gold
val TextLight = Color(0xFFF5F5F5)
val Dim = Color(0xFFA0B2A6)
val CardBg = Color.White.copy(alpha = 0.05f)
val CardBorder: Color get() = Cfg.gold.copy(alpha = 0.2f)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Gold, onPrimary = BgPrimary, secondary = Gold, onSecondary = BgPrimary,
        background = BgPrimary, onBackground = TextLight, surface = BgPrimary, onSurface = TextLight,
        surfaceVariant = BgSecondary, onSurfaceVariant = Dim,
        secondaryContainer = Gold.copy(alpha = 0.25f), onSecondaryContainer = Gold,
        primaryContainer = BgSecondary, onPrimaryContainer = TextLight
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

data class NavTab(val id: Int, val label: String, val icon: ImageVector)

@Composable
fun UpdateBanner() {
    val ctx = LocalContext.current
    if (Cfg.latestCode() > versionCode(ctx)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .background(Gold.copy(alpha = .2f), RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(Cfg.updateMsg().ifEmpty { t("يتوفر إصدار جديد ", "New version available ") + Cfg.latestName() }, Modifier.weight(1f), fontSize = 13.sp)
            if (Cfg.apkUrl().isNotBlank()) TextButton(onClick = {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Cfg.apkUrl())))
            }) { Text(t("تحديث", "Update")) }
        }
    }
}

@Composable
fun PopupDialog() {
    val ctx = LocalContext.current
    var dismissed by remember { mutableStateOf(false) }
    val id = Cfg.popupId()
    if (!dismissed && Cfg.popupEnabled() && id.isNotEmpty() && S.str(ctx, "popup_seen", "") != id) {
        AlertDialog(
            onDismissRequest = { dismissed = true; S.put(ctx, "popup_seen", id) },
            confirmButton = { TextButton(onClick = { dismissed = true; S.put(ctx, "popup_seen", id) }) { Text(t("حسناً", "OK")) } },
            title = { Text(Cfg.popupTitle()) },
            text = { Text(Cfg.popupMessage()) }
        )
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        Cfg.refresh(ctx)
        AdhanScheduler.scheduleNext(ctx); DhikrScheduler.schedule(ctx)
    }
    val lPrayer = stringResource(R.string.tab_prayer)
    val lQibla = stringResource(R.string.tab_qibla)
    val lQuran = stringResource(R.string.tab_quran)
    val lAdhkar = t("الأذكار", "Adhkar")
    val lSettings = t("الإعدادات", "Settings")
    val tabs = mutableListOf(NavTab(0, lPrayer, Icons.Filled.AccessTime))
    if (Cfg.feature("adhkar")) tabs.add(NavTab(1, lAdhkar, Icons.Filled.Favorite))
    if (Cfg.feature("qibla")) tabs.add(NavTab(2, lQibla, Icons.Filled.Explore))
    if (Cfg.feature("quran")) tabs.add(NavTab(3, lQuran, Icons.Filled.MenuBook))
    tabs.add(NavTab(4, lSettings, Icons.Filled.Settings))
    val sel = if (tabs.any { it.id == tab }) tab else 0
    Scaffold(containerColor = BgPrimary, bottomBar = {
        NavigationBar(containerColor = Color(0xFF0F2A21)) {
            tabs.forEach { tb ->
                NavigationBarItem(selected = sel == tb.id, onClick = { tab = tb.id },
                    icon = { Icon(tb.icon, null) }, label = { Text(tb.label, fontSize = 10.sp, maxLines = 1) })
            }
        }
    }) { p ->
        Column(Modifier.padding(p).fillMaxSize()) {
            Text(Cfg.appName(ctx), color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center)
            UpdateBanner()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (sel) { 0 -> PrayerScreen(); 1 -> AdhkarScreen(); 2 -> QiblaScreen(); 3 -> QuranScreen(); else -> SettingsScreen() }
            }
        }
    }
    PopupDialog()
}

private fun hasLoc(c: Context) =
    ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
    ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

@Composable
fun PrayerScreen() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasLoc(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasLoc(ctx); AppEvents.dirty = true
    }
    var day by remember { mutableStateOf<Day?>(null) }
    var error by remember { mutableStateOf(false) }
    var errMsg by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var city by remember { mutableStateOf(LocationHelper.city(ctx)) }

    LaunchedEffect(granted, reload) {
        error = false; errMsg = ""
        if (AppEvents.dirty || reload > 0 || PrayerRepo.day(ctx, LocalDate.now()) == null) {
            val e = PrayerRepo.refreshAll(ctx)
            if (e != null) errMsg = e
            AppEvents.dirty = false
        }
        city = LocationHelper.city(ctx)
        day = PrayerRepo.day(ctx, LocalDate.now())
        if (day == null) { error = true; if (errMsg.isEmpty()) errMsg = "Could not read prayer times" } else AdhanScheduler.scheduleNext(ctx)
    }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }

    val shape12 = RoundedCornerShape(12.dp)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("\uD83D\uDCCD " + city.ifEmpty { "—" }, "\uD83D\uDCC5 " + (day?.hijri ?: "—")).forEach { txt ->
                Box(Modifier.weight(1f).background(CardBg, shape12).border(1.dp, Color.White.copy(alpha = .05f), shape12).padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Text(txt, color = Gold, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        if (!granted && !S.bool(ctx, "loc_manual", false)) Column(Modifier.fillMaxWidth().background(CardBg, shape12).padding(14.dp)) {
            Text(stringResource(R.string.need_location), color = Dim)
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
                launcher.launch(p.toTypedArray())
            }) { Text(stringResource(R.string.allow)) }
        }
        val nxt = PrayerRepo.next(ctx, now, true)
        if (nxt != null) {
            val d = Duration.between(now, nxt.second)
            val f = DateTimeFormatter.ofPattern("HH:mm")
            Column(Modifier.fillMaxWidth().background(CardBg, RoundedCornerShape(20.dp)).border(1.dp, CardBorder, RoundedCornerShape(20.dp)).padding(vertical = 24.dp, horizontal = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                if (Cfg.feature("muezzin_image")) { MuezzinImage(Modifier.size(100.dp)); Spacer(Modifier.height(10.dp)) }
                Text(stringResource(R.string.next_prayer), color = Dim, fontSize = 16.sp)
                Text(prayerLabel(ctx, nxt.first), color = Gold, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                Text(nxt.second.format(f), fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(16.dp))
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf(d.toHours() to R.string.hours, d.toMinutesPart().toLong() to R.string.minutes, d.toSecondsPart().toLong() to R.string.seconds).forEach { (v, l) ->
                            Column(Modifier.widthIn(min = 64.dp).background(Color.Black.copy(alpha = .3f), shape12).border(1.dp, CardBorder, shape12).padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("%02d".format(v), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                Text(stringResource(l), color = Dim, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            val ft = DateTimeFormatter.ofPattern("HH:mm")
            day?.let { dd ->
                PrayerRepo.names.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        pair.forEach { n ->
                            val active = nxt.first == n
                            val bg = if (active) Brush.linearGradient(listOf(Gold.copy(alpha = .25f), BgSecondary.copy(alpha = .8f))) else Brush.linearGradient(listOf(CardBg, CardBg))
                            Column(Modifier.weight(1f).background(bg, RoundedCornerShape(16.dp))
                                .border(1.dp, if (active) Gold else Color.White.copy(alpha = .05f), RoundedCornerShape(16.dp)).padding(vertical = 18.dp),
                                horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(prayerLabel(ctx, n), color = if (active) Gold else TextLight, fontSize = 17.sp)
                                Spacer(Modifier.height(6.dp))
                                Text(dd.times[n]!!.format(ft), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        if (error) { Text(errMsg, color = MaterialTheme.colorScheme.error); Button(onClick = { reload++ }) { Text(stringResource(R.string.retry)) } }
    }
}

private fun qiblaBearing(lat: Double, lon: Double): Double {
    val p1 = Math.toRadians(lat); val p2 = Math.toRadians(21.4225); val dl = Math.toRadians(39.8262 - lon)
    val y = sin(dl) * cos(p2); val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
    return (Math.toDegrees(atan2(y, x)) + 360) % 360
}
private fun distanceKm(lat: Double, lon: Double): Double {
    val r = 6371.0; val p1 = Math.toRadians(lat); val p2 = Math.toRadians(21.4225)
    val dp = p2 - p1; val dl = Math.toRadians(39.8262 - lon)
    val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
    return 2 * r * asin(sqrt(a))
}

@Composable
fun QiblaScreen() {
    val ctx = LocalContext.current
    var pos by remember { mutableStateOf(LocationHelper.saved(ctx)) }
    var azimuth by remember { mutableFloatStateOf(0f) }
    var lowAcc by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { LocationHelper.best(ctx)?.let { pos = it } }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        var sn = 0.0; var cs = 1.0
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val r = FloatArray(9); SensorManager.getRotationMatrixFromVector(r, e.values)
                val o = FloatArray(3); SensorManager.getOrientation(r, o)
                val a = o[0].toDouble()
                sn += 0.1 * (sin(a) - sn); cs += 0.1 * (cos(a) - cs)   // low-pass filter on the angle
                azimuth = Math.toDegrees(atan2(sn, cs)).toFloat()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) { lowAcc = a < SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM }
        }
        if (s != null) sm.registerListener(l, s, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(l) }
    }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        val p = pos
        if (p == null) { Text(stringResource(R.string.need_location)); return@Column }
        val q = qiblaBearing(p.first, p.second).toFloat()
        val diff = ((q - azimuth + 540) % 360) - 180
        val aligned = abs(diff) < 3
        val color = if (aligned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
        Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().rotate(-azimuth)) { // dial turns with the phone, N marker at top
                drawCircle(color.copy(alpha = .2f)); drawCircle(color, style = androidx.compose.ui.graphics.drawscope.Stroke(4f))
                drawLine(Color.Red, Offset(size.width / 2, 8f), Offset(size.width / 2, 40f), strokeWidth = 6f)
            }
            Canvas(Modifier.fillMaxSize().rotate(q - azimuth)) {
                val cx = size.width / 2; val path = Path().apply {
                    moveTo(cx, 30f); lineTo(cx - 28f, size.height / 2); lineTo(cx + 28f, size.height / 2); close() }
                drawPath(path, color)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.qibla_info, q.roundToInt(), distanceKm(p.first, p.second).roundToInt()), fontSize = 18.sp)
        if (lowAcc) Text(stringResource(R.string.calibrate), color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
    }
}

@Composable
fun QuranScreen() {
    var list by remember { mutableStateOf<List<Surah>?>(null) }
    var err by remember { mutableStateOf(false) }
    var tries by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Surah?>(null) }
    LaunchedEffect(tries) { err = false; try { list = QuranRepo.surahs() } catch (_: Exception) { err = true } }
    BackHandler(open != null) { open = null }
    val s = open
    when {
        s != null -> Reader(s)
        list != null -> LazyColumn { items(list!!) { sr ->
            ListItem(headlineContent = { Text(sr.en) }, supportingContent = { Text("${sr.count}") },
                leadingContent = { Text("${sr.n}") }, trailingContent = { Text(sr.ar, fontSize = 20.sp) },
                modifier = Modifier.clickable { open = sr })
            HorizontalDivider()
        } }
        err -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Button(onClick = { tries++ }) { Text(stringResource(R.string.retry)) } }
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable
fun Reader(s: Surah) {
    var ayahs by remember { mutableStateOf<List<String>>(emptyList()) }
    var size by rememberSaveable { mutableFloatStateOf(26f) }
    var reciter by rememberSaveable { mutableStateOf(RECITERS[0].first) }
    var playing by remember { mutableStateOf(false) }
    var idx by remember { mutableIntStateOf(-1) }
    var err by remember { mutableStateOf(false) }
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(s) { try { ayahs = QuranRepo.ayahs(s.n) } catch (_: Exception) { err = true } }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(p: Boolean) { playing = p }
            override fun onMediaItemTransition(m: MediaItem?, r: Int) { idx = AudioPlayer.exo.currentMediaItemIndex }
        }
        AudioPlayer.exo.addListener(l)
        onDispose { AudioPlayer.exo.removeListener(l); AudioPlayer.exo.stop() }
    }
    LaunchedEffect(idx) { if (idx in ayahs.indices) state.animateScrollToItem(idx) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text("${s.n}. ${s.en} — ${s.ar}", fontSize = 18.sp)
            Text("${stringResource(R.string.text_size)}: ${size.roundToInt()}")
            Slider(value = size, onValueChange = { size = it }, valueRange = 16f..52f)
            Text(stringResource(R.string.reciter))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(RECITERS) { (id, nm) ->
                FilterChip(selected = reciter == id, onClick = { reciter = id; AudioPlayer.exo.stop(); idx = -1 }, label = { Text(nm) }) } }
            Button(onClick = {
                if (playing) AudioPlayer.exo.stop() else scope.launch {
                    try {
                        val urls = QuranRepo.audio(s.n, reciter)
                        AudioPlayer.exo.setMediaItems(urls.map { MediaItem.fromUri(it) })
                        AudioPlayer.exo.prepare(); AudioPlayer.exo.play()
                    } catch (_: Exception) { err = true }
                }
            }) { Text(stringResource(if (playing) R.string.stop else R.string.play)) }
        }
        if (err) Text(stringResource(R.string.retry), Modifier.padding(16.dp))
        if (ayahs.isEmpty() && !err) Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        LazyColumn(state = state, contentPadding = PaddingValues(16.dp)) {
            itemsIndexed(ayahs) { i, t ->
                Text("$t ﴿${i + 1}﴾", Modifier.fillMaxWidth()
                    .background(if (i == idx) MaterialTheme.colorScheme.primary.copy(alpha = .18f) else Color.Transparent, RoundedCornerShape(10.dp))
                    .padding(vertical = 8.dp, horizontal = 6.dp),
                    style = TextStyle(fontSize = size.sp, lineHeight = (size * 1.8f).sp, textDirection = TextDirection.Rtl),
                    textAlign = TextAlign.Start)
            }
        }
    }
}
