# Adhan & Quran (Android, Kotlin + Jetpack Compose)

Open the folder in Android Studio (Koala+), let Gradle sync, run on a device (location + sensors work best on a real phone).

- Prayer times: Aladhan calendar API (method auto-selected by location), cached monthly for offline use, exact alarms re-scheduled after each prayer and on boot.
- Adhan sound: put `adhan.mp3` in `app/src/main/res/raw/` (licensed / royalty-free). Without it the default notification sound is used.
- Qibla: bearing + distance math, rotation-vector sensor with low-pass filter.
- Quran: text + audio from api.alquran.cloud (cached on disk), font-size slider, 5 reciters, verse highlight.
- Languages follow the phone (ar/ur RTL automatically): en, ar, fr, es, pt, it, de, tr, ur, id, ru. Add more via `values-xx/strings.xml` + `res/xml/locales_config.xml`. Unsupported languages fall back to English.
